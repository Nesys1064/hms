<?php
    class POW{
        public static function hash($message){
            return hash('sha256', $message);
        }
        public static function findNounce($message){
            $nounce = 0;
            while(!self::isValidNounce($message, $nounce)){
                ++$nounce;
            }
            return $nounce;
        }
        public static function isValidNounce($message, $nounce){
            //difficulty is the number of zeros we want
            return 0 === strpos(hash('sha256', $message.$nounce), '00');
        }
    }
    
?>