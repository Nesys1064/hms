<?php
session_start();
include('include/config.php');
$_SESSION['dlogin']=="";
date_default_timezone_set('Africa/Nairobi');
$datetime = date("Y-m-d h:i:sa"); 
mysqli_query($con,"UPDATE doctorslog  SET logout = '$datetime' WHERE uid = '".$_SESSION['id']."' ORDER BY id DESC LIMIT 1");
session_unset();
$_SESSION['errmsg']="You have successfully logout";
?>
<script language="javascript">
document.location="../../index.html";
</script>
