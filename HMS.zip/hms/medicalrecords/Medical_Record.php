<?php
    include('crypto/pki.php');
    include('pow/pow.php');
    class MediRecord{
        //public key masks the user
        public $from;
        public $to;
        public $data; 

        public $signature;
        public function __construct(?string $from, string $to, $data, $privKey){
            $this->from = $from;
            $this->to = $to;
            // $this->medicine = $medicine;
            $this->data = $data;
            //encrypt
            $this->signature = Pki::encrypt($this->message(), $privKey);
        }

        public function message(){
            $dat = '';
            foreach($this->data as $key => $value){
                $dat .= $value;
            }
            //authentication
            return POW::hash($this->from.$this->to.$dat);
            // return $this->name.$this->illness.$this->medicine.$this->amount;

        }
        public function isValid(){
            return !$this->from  || Pki::isValid($this->message(), $this->signature, $this->from);
        }
        public function __toString():string{
            $amm = ' ';
            foreach($this->amount as $key => $value){
                $amm .= $value;
            }
            // return sprintf("Previous: %s\nNounce: %s\nHash: %s\nMessage: %s", $this->previous, $this->nonce, $this->hash, $this->mediRecord->message());
            return ($this->from ? substr($this->from, 72,7) : 'NONE').' -> '.substr($this->to, 72,7). '  DATA: '.$amm;

        }

    }

    class Block{
        public $nonce;
        public $hash;
        public $mediRecord;

        public function __construct(MediRecord $mediRecord, ?self $previous){
            $this->previous = $previous ? $previous->hash : null;
            $this->mediRecord = $mediRecord;
            $this->mine();
        }

        public static function createBegining(string $to, string $privKey, $amount){
            return new self(new MediRecord(null, $to, $amount, $privKey), null);
        }
        //proof of work
        public function mine(){
            $data = $this->mediRecord->message().$this->previous;
            $this->nonce = POW::findNounce($data);
            $this->hash = POW::hash($data.$this->nonce);
        }
        public function isValid():bool{
            return POW::isValidNounce($this->mediRecord->message().$this->previous, $this->nonce) && $this->mediRecord->isValid();
        }
        public function __toString():string{
            // return sprintf("Previous: %s\nNounce: %s\nHash: %s\nMessage: %s", $this->previous, $this->nonce, $this->hash, $this->mediRecord->message());
            return sprintf("%s\n %s -- %s -- %s", $this->mediRecord, $this->nonce, substr($this->hash, 0,10), substr($this->previous,0,10) ?? 'NONE');

        }
    }
?>