<?php
    include('Medical_Record.php');

    //order
    class Blockchain{
        public $blocks = [];

        public function __construct($to, $data, $privKey){
            $this->blocks[] = Block::createBegining($to,$privKey, $data);
        }

        public function add(MediRecord $message){
            $this->blocks[] = new Block($message, $this->blocks[count($this->blocks) - 1]);
        }
        public function isValid():bool{
            foreach($this->blocks as $i => $block){
                if(!$block->isValid()){
                    return false;
                }
                if($i != 0 && $this->blocks[$i - 1]->hash != $block->previous){
                    return false;
                }
            }
            return true;
        }

        public function __toString(){
            return implode("\n\n", $this->blocks);
        }
    }
    

?>