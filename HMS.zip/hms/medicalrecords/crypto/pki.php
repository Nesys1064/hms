<?php
    class Pki{
        public static function generateKeyPair(){
            $conf = 'C:/xammp2/apache/conf/openssl.cnf';
            // temp($conf);
            //generate private key
            $config = array(        
                    "private_key_bits" => 4096,
                    "private_key_type" => OPENSSL_KEYTYPE_RSA,
                    "config" => 'C:/xammp2/apache/conf/openssl.cnf',
                
            );
            $res = openssl_pkey_new($config);
        
            openssl_pkey_export($res, $priKey,NULL, $config);
            return [$priKey, openssl_pkey_get_details($res)['key']];
        }
        public static function encrypt($message, $privKey){
            openssl_private_encrypt($message, $crypted, $privKey); 
            return base64_encode($crypted);
        }
        public static function decrypt($crypted, $pubKey){
            openssl_public_decrypt(base64_decode($crypted), $decrpted, $pubKey);
            return $decrpted;
        }

        public static function isValid($message, $crypted, $pubKey):bool{
            return $message == self::decrypt($crypted, $pubKey);
        }
    }


?>